###################
## Instructions: ##
###################

Simply upload all the relevant files using the correct upload button (the filenames will tell you which file goes where), then click on the darkred ‘replot’ button.

###################
NB:

i) Select both interaction files (plotA_interactions_3q26.txt, plotA_interactions_8q24.txt) when uploading the interaction files (simply hold the ctrl or cmd key when selecting files).

ii) The multi-state annotation legend file (plotA_legend_multistate_annot_rgb.txt) has to be uploaded from the ‘Legend(s)’ menu panel, not the main ‘Data Files’ panel.

iii) You don’t have to upload all the files; the tracks with missing data will simply not be plotted; note though that omitting only one of the two SNAP files will trigger an error message, so either leave both out or upload them both. Omitting the legend file will also trigger a fatal error message unless you set the option to plot a multi-state annotation legend to ‘No’ in the ‘Legend(s)’ menu panel.

iv) To save the image in PNG format, simply right-click on the plot and select ‘save image as’. To save the image in PDF format, click the green ‘download the PDF’ button; the image will be regenerated in PDF format, so there will be a small delay before a download dialogue box pops up.

###################
