###################
## Instructions: ##
###################

Simply upload all the relevant files using the correct upload button (the filenames will tell you which file goes where), then click on the darkred ‘replot’ button.

###################
NB:

i) You don’t have to upload all the files; the tracks with missing data will simply not be plotted.

ii) To save the image in PNG format, simply right-click on the plot and select ‘save image as’. To save the image in PDF format, click the green ‘download the PDF’ button; the image will be regenerated in PDF format, so there will be a small delay before a download dialogue box pops up.

###################
